/***************************************************************************
  
  e-puck_drive -- E-puck robot evolves to drive in an arena and avoid walls
  This program is free software; any publications presenting results
  obtained with this program must mention it and its origin. You 
  can redistribute it and/or modify it under the terms of the GNU 
  General Public License as published by the Free Software 
  Foundation; either version 2 of the License, or (at your option) 
  any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
  USA.

***************************************************************************/

#include "e-puck_drive.h"

int main(int argc, char **argv)
{
  //robot_live(reset);
 // robot_run(run);

  /* necessary to initialize webots stuff */
  wb_robot_init();
  //TIME_STEP = (int)wb_robot_get_basic_time_step();
  int n=reset();
  printf("did reset: %d\n",n);
  /*
   * You should declare here WbDeviceTag variables for storing
   * robot devices like this:
   *  WbDeviceTag my_sensor = wb_robot_get_device("my_sensor");
   *  WbDeviceTag my_actuator = wb_robot_get_device("my_actuator");
   */
  
  /* main loop
   * Perform simulation steps of TIME_STEP milliseconds
   * and leave the loop when the simulation is over
   */
  while (wb_robot_step(TIME_STEP) != -1) {
    
    /* 
     * Read the sensors :
     * Enter here functions to read sensor data, like:
     *  double val = wb_distance_sensor_get_value(my_sensor);
     */
    run(TIME_STEP);
    /* Process sensor data here */
    
    /*
     * Enter here functions to send actuator commands, like:
     * wb_differential_wheels_set_speed(100.0,100.0);
     */
  };
  
  /* Enter your cleanup code here */
  
  /* This is necessary to cleanup webots resources */
  wb_robot_cleanup();
  
  return 0;
}

//
// Reset the robot controller and initiate the sensors and emitter/receiver
//
static int reset()
{  
  int i;
  mode =1;
  emitter = wb_robot_get_device("emitter");
  //buffer = (double *) emitter_get_buffer(emitter);
 
  receiver = wb_robot_get_device("receiver");
  
  wb_receiver_enable(receiver, TIME_STEP);
  
  char text[5]="led0";
  for(i=0;i<NB_LEDS;i++) {
    led[i]=wb_robot_get_device(text); // get a handler to the sensor 
    text[3]++; // increase the device name to "ps1", "ps2", etc. 
  }
  
  text[0]='p';
  text[1]='s';
  text[3]='\0';
  
  text[2]='0';
  ps[0] = wb_robot_get_device(text); // proximity sensors
  text[2]='7';
  ps[1] = wb_robot_get_device(text); // proximity sensors
  text[2]='1';
  ps[2] = wb_robot_get_device(text); // proximity sensors
  text[2]='6';
  ps[3] = wb_robot_get_device(text); // proximity sensors
  text[2]='2';
  ps[4] = wb_robot_get_device(text); // proximity sensors
  text[2]='5';
  ps[5] = wb_robot_get_device(text); // proximity sensors
  text[2]='3';
  ps[6] = wb_robot_get_device(text); // proximity sensors
  text[2]='4';
  ps[7] = wb_robot_get_device(text); // proximity sensors

  // Enable proximity and floor sensors
  for(i=0;i<NB_DIST_SENS;i++) {
    wb_distance_sensor_enable(ps[i],TIME_STEP);
    printf("ps[%d] is active\n",i);
  }
  
  // Enable GPS sensor to determine position
  gps=wb_robot_get_device("gps");
  wb_gps_enable(gps, TIME_STEP);
  printf("gps is active\n");
  
  return 1;
}

//------------------------------------------------------------------------------
//
//    CONTROLLER
//
//------------------------------------------------------------------------------

////////////////////////////////////////////
// Main
static int run(int ms)
{
  int i;
  if (mode!=wb_robot_get_mode())
  {
    mode = wb_robot_get_mode();
    if (mode == SIMULATION) {
      for(i=0;i<NB_DIST_SENS;i++) ps_offset[i]=PS_OFFSET_SIMULATION[i];
      printf("Switching to SIMULATION.\n\n");
    } 
    else if (mode == REALITY) { 
      for(i=0;i<NB_DIST_SENS;i++) ps_offset[i]=PS_OFFSET_REALITY[i];
      printf("\nSwitching to REALITY.\n\n");
    }
  }

  // if we're testing a new genome, receive weights and initialize trial
  if (step == 0) {
    int n = wb_receiver_get_queue_length(receiver);
    printf("queue length %d\n",n);
    //wait for new genome
    if (n) {
      const double *genes = (double *) wb_receiver_get_data(receiver);
      //set neural network weights
      for (i=0;i<NB_WEIGHTS;i++) weights[i]=genes[i];
      printf("wt[%d]: %g\n",i,weights[i]);
      wb_receiver_next_packet(receiver);
    }
    
    
    else {
     // printf("time step %d\n",TIME_STEP);
      return TIME_STEP;}
    
    const double *gps_matrix = wb_gps_get_values(gps);
    robot_initial_position[0] = gps_matrix[0];//gps_position_x(gps_matrix);
    robot_initial_position[1] = gps_matrix[2];//gps_position_z(gps_matrix);
    printf("rip[0]: %g, rip[1]: %g\n",robot_initial_position[0],robot_initial_position[1]);
    fitness = 0;
  }
  
  step++;
  printf("Step: %d\n", step);
    
  if(step < TRIAL_DURATION/(double)TIME_STEP) {
    //drive robot
    fitness+=run_trial();
    //send message with current fitness
    double msg[2] = {fitness, 0.0};
    wb_emitter_send(emitter, (void *)msg, 2*sizeof(double));
  }
  else {
    //stop robot
    wb_differential_wheels_set_speed(0, 0);
    //send message to indicate end of trial
    double msg[2] = {fitness, 1.0};
    wb_emitter_send(emitter, (void *)msg, 2*sizeof(double));
    //reinitialize counter
    step = 0;
  }
  
  return TIME_STEP;
  return TIME_STEP;
}

//
// Trial to test the robot's behavior (according to NN) in the environment
//
double run_trial() {

  double inputs[NB_INPUTS];
  double outputs[NB_OUTPUTS];
  
  //Get position of the e-puck
  static double position[3]={0.0,0.0,0.0};
  const double *gps_matrix = wb_gps_get_values(gps);
  position[0] = gps_matrix[0];//gps_position_x(gps_matrix);
  position[1] = gps_matrix[2];//gps_position_z(gps_matrix);
  position[2] = gps_matrix[1];//gps_position_y(gps_matrix);
  
  //Speed of the robot's wheels within the +SPEED_RANGE and -SPEED_RANGE values
  int speed[2]={0,0};
  //Maximum activation of all IR proximity sensors [0,1]
  double maxIRActivation = 0;

  //get sensor data, i.e., NN inputs
  int i, j;
  for(j=0;j<NB_INPUTS;j++) {
    inputs[j]=(((double)wb_distance_sensor_get_value(ps[j])-ps_offset[j])<0)?0:((double)wb_distance_sensor_get_value(ps[j])-ps_offset[j])/((double)PS_RANGE);
    //get max IR activation
    if(inputs[j]>maxIRActivation) maxIRActivation=inputs[j];
    printf("sensor #: %d, sensor read: %g, maxIR: %g\n", j, inputs[j], maxIRActivation);
  }
  //printf("max IR activation: %f\n", maxIRActivation);

  // Run the neural network and computes the output speed of the robot
  run_neural_network(inputs, outputs); 
  
  speed[LEFT]  = SPEED_RANGE*outputs[0];
  speed[RIGHT] = SPEED_RANGE*outputs[1];
  
  // If you are running against an obstacle, stop the wheels
  if ( maxIRActivation > 0.9 ) {
    speed[LEFT]=0;
    speed[RIGHT]=0;
  }
  // Set wheel speeds to output values
  wb_differential_wheels_set_speed(speed[LEFT], speed[RIGHT]); //left, right
  
  // Stop the robot if it is against an obstacle
  for (i=0;i<NB_DIST_SENS;i++) {
    int tmpps=(((double)wb_distance_sensor_get_value(ps[i])-ps_offset[i])<0)?0:((double)wb_distance_sensor_get_value(ps[i])-ps_offset[i]);
    
    if(OBSTACLE_THRESHOLD<tmpps ) {// proximity sensors 
      //printf("%d \n",tmpps);
      speed[LEFT]  = 0;
      speed[RIGHT] = 0;
      break;
    }
  }
  
  return compute_fitness(speed, position, maxIRActivation);
}

//
// Computes the fitness of the robot at each timestep.
//
double compute_fitness(int speed[2], double position[3], double maxIRActivation)
{
  double fitness= speed[0]*speed[1]/maxIRActivation; 
  /*
  Input parameters:
  
  speed[0] //leftSpeed
  speed[1] //rightSpeed
  
  SPEED_RANGE //all speed outputs are within the +SPEED_RANGE and -SPEED_RANGE values
  
  position[0] //current X coordinate
  position[1] //current Y coordinate
  
  robot_initial_position[0] //initial X coordinate
  robot_initial_position[1] //initial Y coordinate
  
  maxIRActivation //highest IR sensor activation [0,1]
  */
  printf("fitness: %g\n", fitness);
  return fitness;
}

//
// Run the neural network
//
void run_neural_network(double* inputs, double* outputs)
{
  int i,j;
  int weight_counter=0;
  
  if(NB_HIDDEN_NEURONS>0){
    double hidden_neuron_out[(int)NB_HIDDEN_NEURONS];
    
    for(i=0;i<NB_HIDDEN_NEURONS;i++) {
      double sum=0;
      for(j=0;j<NB_INPUTS;j++) {
        sum+=inputs[j]*weights[weight_counter];
        weight_counter++;
      }
      hidden_neuron_out[i]=tanh(sum+weights[weight_counter]);
      weight_counter++;
    }
    
    for(i=0;i<NB_OUTPUTS;i++) {
      double sum=0;
      for(j=0;j<NB_HIDDEN_NEURONS;j++)
      {
        sum+=hidden_neuron_out[j]*weights[weight_counter];
        weight_counter++;
      }
      outputs[i]=tanh(sum+weights[weight_counter]);
      weight_counter++;
    }
  }
  else
  {
    for(i=0;i<NB_OUTPUTS;i++) {
      double sum=0.0;
      for(j=0;j<NB_INPUTS;j++)
      {
        sum+=inputs[j]*weights[weight_counter];
        weight_counter++;
      } 
      outputs[i]=tanh(sum+weights[weight_counter]);
      weight_counter++;
    }
  }

  return;
}

