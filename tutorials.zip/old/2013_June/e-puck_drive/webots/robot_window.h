#ifndef ROBOT_WINDOW_H
#define ROBOT_WINDOW_H

#ifdef __cplusplus
extern "C" {
#endif

void *wb_robot_window_custom_function(void *);

#ifdef __cplusplus
}
#endif

#endif //ROBOT_WINDOW_H
